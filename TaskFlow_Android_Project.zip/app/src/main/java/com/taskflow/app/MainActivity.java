package com.taskflow.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.database.sqlite.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root, content;
    TextView title;
    final String[] statuses={"NEW","OPEN","IN PROGRESS","BLOCKED","CLOSED"};
    final String[] priorities={"Low","Medium","High","Critical"};

    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(dp(12),dp(10),dp(12),dp(10)); return t; }
    Button btn(String s){Button b=new Button(this); b.setText(s); return b;}

    @Override public void onCreate(Bundle b){
        super.onCreate(b); db=new DB(this); showLogin();
    }

    void showLogin(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(28),dp(80),dp(28),dp(20));
        TextView h=tv("TaskFlow",32); root.addView(h);
        root.addView(tv("Personal productivity & task management",16));
        EditText u=new EditText(this); u.setHint("Username"); root.addView(u);
        EditText p=new EditText(this); p.setHint("Password"); p.setInputType(0x81); root.addView(p);
        Button login=btn("LOGIN"); root.addView(login);
        login.setOnClickListener(v->{ if(u.getText().toString().equals("admin")&&p.getText().toString().equals("admin")) showApp(); else Toast.makeText(this,"Use admin / admin",Toast.LENGTH_SHORT).show();});
        setContentView(root);
    }

    void showApp(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL);
        title=tv("TaskFlow",22); top.addView(title,new LinearLayout.LayoutParams(0,dp(60),1));
        Button theme=btn("☾"); top.addView(theme,new LinearLayout.LayoutParams(dp(70),dp(60)));
        root.addView(top);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);
        String[] n={"Dashboard","Kanban","Tasks","Goals","Backup"};
        for(String x:n){Button q=btn(x); nav.addView(q,new LinearLayout.LayoutParams(0,dp(58),1)); q.setOnClickListener(v->{
            if(x.equals("Dashboard")) dashboard(); else if(x.equals("Kanban")) kanban(); else if(x.equals("Tasks")) tasks(); else if(x.equals("Goals")) goals(); else backup();
        });}
        root.addView(nav); setContentView(root); dashboard();
        theme.setOnClickListener(v->{ root.setBackgroundColor(root.getSolidColorBackground()==Color.WHITE?Color.rgb(32,32,32):Color.WHITE);});
    }

    void clear(){content.removeAllViews();}
    void dashboard(){
        clear(); content.addView(tv("Dashboard",28));
        content.addView(tv("Tasks: "+db.count("tasks"),18));
        content.addView(tv("Open: "+db.countWhere("status='OPEN'"),16));
        content.addView(tv("In Progress: "+db.countWhere("status='IN PROGRESS'"),16));
        content.addView(tv("Blocked: "+db.countWhere("status='BLOCKED'"),16));
        content.addView(tv("Closed: "+db.countWhere("status='CLOSED'"),16));
        content.addView(tv("Goals: "+db.count("goals"),16));
        Button add=btn("+ New Task"); content.addView(add); add.setOnClickListener(v->taskDialog());
    }

    void kanban(){
        clear(); content.addView(tv("Kanban Board",28));
        for(String s:statuses){
            content.addView(tv("━━ "+s+" ━━",19));
            Cursor c=db.getTasks(s);
            while(c.moveToNext()){TextView x=tv(c.getString(1)+"  ["+c.getString(3)+"]",16); content.addView(x);}
            c.close();
        }
        Button add=btn("+ New Task"); content.addView(add); add.setOnClickListener(v->taskDialog());
    }

    void tasks(){
        clear(); content.addView(tv("Tasks",28));
        EditText search=new EditText(this); search.setHint("Search tasks"); content.addView(search);
        Button add=btn("+ New Task"); content.addView(add); add.setOnClickListener(v->taskDialog());
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); content.addView(list);
        Runnable refresh=()->{list.removeAllViews(); Cursor c=db.allTasks(search.getText().toString()); while(c.moveToNext()){TextView x=tv(c.getString(1)+"\n"+c.getString(2)+" • "+c.getString(3)+" • "+c.getString(4),16); list.addView(x);} c.close();};
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){} public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();} public void afterTextChanged(android.text.Editable e){}}); refresh.run();
    }

    void goals(){
        clear(); content.addView(tv("Goals",28));
        Button add=btn("+ New Goal"); content.addView(add); add.setOnClickListener(v->goalDialog());
        Cursor c=db.allGoals(); while(c.moveToNext()) content.addView(tv("• "+c.getString(1)+" ("+c.getString(2)+")",17)); c.close();
    }

    void taskDialog(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(20,10,20,10);
        EditText name=new EditText(this); name.setHint("Task name"); l.addView(name);
        EditText desc=new EditText(this); desc.setHint("Description"); l.addView(desc);
        Spinner st=new Spinner(this); st.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,statuses)); l.addView(st);
        Spinner pr=new Spinner(this); pr.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,priorities)); l.addView(pr);
        CheckBox urgent=new CheckBox(this); urgent.setText("Urgent"); l.addView(urgent);
        CheckBox important=new CheckBox(this); important.setText("Important"); l.addView(important);
        new AlertDialog.Builder(this).setTitle("New Task").setView(l).setPositiveButton("Save",(d,w)->{db.addTask(name.getText().toString(),desc.getText().toString(),st.getSelectedItem().toString(),pr.getSelectedItem().toString(),urgent.isChecked(),important.isChecked()); dashboard();}).setNegativeButton("Cancel",null).show();
    }

    void goalDialog(){
        EditText e=new EditText(this); e.setHint("Goal name");
        new AlertDialog.Builder(this).setTitle("New Goal").setView(e).setPositiveButton("Save",(d,w)->{db.addGoal(e.getText().toString(),"LONG TERM"); goals();}).setNegativeButton("Cancel",null).show();
    }

    void backup(){
        clear(); content.addView(tv("Local Backup & Restore",28));
        content.addView(tv("Data is stored locally in SQLite. Use Android document sharing to export/restore a JSON backup.",16));
        Button exp=btn("Export backup"); content.addView(exp); exp.setOnClickListener(v->Toast.makeText(this,"Export hook ready for ACTION_CREATE_DOCUMENT",Toast.LENGTH_LONG).show());
        Button imp=btn("Restore backup"); content.addView(imp); imp.setOnClickListener(v->Toast.makeText(this,"Restore hook ready for ACTION_OPEN_DOCUMENT",Toast.LENGTH_LONG).show());
    }

    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"taskflow.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,description TEXT,status TEXT,priority TEXT,urgent INTEGER,important INTEGER,start TEXT,end TEXT,goal TEXT)"); d.execSQL("CREATE TABLE goals(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,type TEXT)");}
        public void onUpgrade(SQLiteDatabase d,int a,int b){}
        int count(String t){Cursor c=getReadableDatabase().rawQuery("SELECT count(*) FROM "+t,null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        int countWhere(String w){Cursor c=getReadableDatabase().rawQuery("SELECT count(*) FROM tasks WHERE "+w,null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        void addTask(String n,String desc,String st,String pr,boolean u,boolean im){ContentValues v=new ContentValues();v.put("name",n);v.put("description",desc);v.put("status",st);v.put("priority",pr);v.put("urgent",u?1:0);v.put("important",im?1:0);getWritableDatabase().insert("tasks",null,v);}
        void addGoal(String n,String type){ContentValues v=new ContentValues();v.put("name",n);v.put("type",type);getWritableDatabase().insert("goals",null,v);}
        Cursor getTasks(String s){return getReadableDatabase().query("tasks",null,"status=?",new String[]{s},null,null,"priority DESC");}
        Cursor allTasks(String q){return getReadableDatabase().query("tasks",null,"name LIKE ? OR description LIKE ?",new String[]{"%"+q+"%","%"+q+"%"},null,null,"id DESC");}
        Cursor allGoals(){return getReadableDatabase().query("goals",null,null,null,null,null,"id DESC");}
    }
}